<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Asus\Documents\tmn-backend\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>